module.exports = {
    // ═══════════════════════════════════════════════════
    //  🤖  BOT CONFIGURATION
    // ═══════════════════════════════════════════════════
    
    mainToken: '8472832431:AAFHb8pdGCBcyeX06o_jPgq-CQUxyasz3y8',
    
    S7: '@Cipher4n',
    
    adminId: '7684184696',
    
    bot: 'CIHPER4N',
    
    logo: './SY/Loves.jpg',
    
    // ═══════════════════════════════════════════════════
    //  🔗  VERIFICATION LINKS (4 Channel Verification)
    // ═══════════════════════════════════════════════════
    
    // ⚠️ IMPORTANT: Bot ko in channels/groups mein ADMIN banana ZAROORI hai!
    
    // Telegram Channel (Join karne ke liye)
    verifyChannel: 'https://t.me/leader_otp_zone',
    
    // Telegram Group (Join karne ke liye)
    verifyGroup: 'https://t.me/leader_otp_zone',
    
    // YouTube Channel (Subscribe karne ke liye)
    verifyYoutube: 'https://youtube.com/@hunter_x_hacker-999?si=SwR_9Rnx_FNMyAia',
    
    // WhatsApp Channel/User (Join karne ke liye)
    verifyWhatsapp: 'https://chat.whatsapp.com/HCtKQ6Us4RUFH8ZBiMkQu8?mode=gi_t',
    
    // ═══════════════════════════════════════════════════
    //  🔗  SOCIAL LINKS (Menu buttons ke liye)
    // ═══════════════════════════════════════════════════
    
    channel: 'https://t.me/leader_otp_zone',
    
    group: 'https://t.me/leader_otp_zone',
    
    youtube: 'https://youtube.com/@hunter_x_hacker-999?si=SwR_9Rnx_FNMyAia',
    
    whatsapp: 'https://chat.whatsapp.com/HCtKQ6Us4RUFH8ZBiMkQu8?mode=gi_t',
    
    // ═══════════════════════════════════════════════════
    //  🆔  CHAT IDs (Verification check ke liye)
    // ═══════════════════════════════════════════════════
    
    // Bot ko admin banao, phir /start se yeh IDs auto-capture hongi
    // Ya manually @userinfobot se channel/group ki ID nikaalo
    
    channelId: '--1003635194666', // Channel ki ID (-100... format mein)
    groupId: '--1003635194666',   // Group ki ID
    
    // ═══════════════════════════════════════════════════
    //  💰  PRICING & MESSAGES
    // ═══════════════════════════════════════════════════
    
    prices: {
        permanent: 15,
        resell: 30,
        script: 100
    },
    
    currency: '$',
    
    // ═══════════════════════════════════════════════════
    //  ⚙️  BOT SETTINGS
    // ═══════════════════════════════════════════════════
    
    settings: {
        maxBotsPerUser: 5,
        verifyRequired: true,
        premiumOnly: true,
        welcomeAnimation: true,
        notifyOnPremium: true
    },
    
    // ═══════════════════════════════════════════════════
    //  🎨  UI CUSTOMIZATION
    // ═══════════════════════════════════════════════════
    
    ui: {
        theme: 'dark',
        animations: true,
        fancyText: true,
        showStatus: true
    },
    
    // ═══════════════════════════════════════════════════
    //  📢  MESSAGES
    // ═══════════════════════════════════════════════════
    
    messages: {
        notVerified: '🚫 Please verify yourself first! Use /start',
        notPremium: '🔒 Premium access required! Contact admin to buy.',
        notAuthorized: '⛔ You are not authorized to use this command.',
        welcomeVerified: '✅ Welcome! You have been verified successfully.',
        premiumAdded: '⭐ Congratulations! Your account has been upgraded to PREMIUM!',
        premiumRemoved: '💔 Your premium access has been revoked.'
    }
};
